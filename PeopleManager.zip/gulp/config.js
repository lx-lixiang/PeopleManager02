var mainDir = 'static/';
var app = mainDir+'app/';
var dist = mainDir+'dist/';
var lessCache = '.lessCache';
module.export = function(){

}
