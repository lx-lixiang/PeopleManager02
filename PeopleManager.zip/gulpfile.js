var requireDir = require('require-dir');
var dir = requireDir('./gulp');
