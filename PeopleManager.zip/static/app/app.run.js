angular.module('manager').run(function($rootScope,$location,$window){
    $rootScope.login = true;
    $rootScope.username = '';
})
