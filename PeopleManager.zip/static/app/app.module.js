angular.module('manager',['ngRoute'],function(){

});
